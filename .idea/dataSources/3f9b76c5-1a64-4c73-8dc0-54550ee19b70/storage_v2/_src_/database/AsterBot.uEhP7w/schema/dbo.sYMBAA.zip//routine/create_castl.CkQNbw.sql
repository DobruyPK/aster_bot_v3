Create PROCEDURE [dbo].[create_castl]
(@name varchar(200),@waittime datetime2, @server varchar(200))
AS
insert into
[dbo].[Castles] 
([name], [time],[server])
values (@name,@waittime, @server)
go

