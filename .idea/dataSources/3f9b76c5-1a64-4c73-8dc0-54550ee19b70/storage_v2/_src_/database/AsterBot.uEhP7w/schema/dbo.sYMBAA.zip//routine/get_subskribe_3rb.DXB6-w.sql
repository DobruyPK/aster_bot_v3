CREATE PROCEDURE [dbo].[get_subskribe_3rb]
(@tg_id int, @bossname varchar(200), @server varchar(200))
AS
select *
from [dbo].[subskribe_3rb]
where [userid] in (SELECT [id]
                FROM [dbo].[Users]
                WHERE [telegram_id] = @tg_id) and [bossname] = @bossname and [server]= @server
go

