CREATE PROCEDURE [dbo].[get_subscribe]
(@tg_id int, @bossname varchar(200), @server varchar(200))
AS
select *
from [dbo].[subskribes]
where userid in (SELECT [id]
                FROM [dbo].[Users]
                WHERE [telegram_id] = @tg_id) and 
				[bosid] in(SELECT [id]
								FROM [dbo].[bosses]
								WHERE [bossname]=@bossname and [server] = @server )
go

