CREATE PROCEDURE [dbo].[update_boss]
(@bossname varchar(200),@killdatettime datetime2, @startresp datetime2, @endresp datetime2, @server varchar(200))
AS
UPDATE [dbo].[bosses]
SET
[killdatettime] = @killdatettime,
[startresp] = @startresp,
[endresp] = @endresp
WHERE [bossname] = @bossname and [Server]= @server;
go

