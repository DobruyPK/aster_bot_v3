CREATE PROCEDURE [dbo].[create_subscribe_3rb]
(@tg_id int,@bossname varchar(200),@subsckribe_tybe varchar(200),@not_time datetime2, @server varchar(200), @timekill datetime2)
AS
if @subsckribe_tybe = 'not_1h'
	insert into [dbo].[subskribe_3rb] ([userid], [bossname],[not_1h], [server], [time_kill] )
	values
		((select [id]
			from [dbo].[Users]
			Where [telegram_id] = @tg_id),
		@bossname, @not_time, @server, @timekill);
else if @subsckribe_tybe = 'not_30m'
	insert into [dbo].[subskribe_3rb] ([userid], [bossname],[not_30m], [server], [time_kill] )
	values
		((select [id]
			from [dbo].[Users]
			Where [telegram_id] = @tg_id),
		@bossname, @not_time, @server, @timekill);
else if @subsckribe_tybe = 'not_15m'
	insert into [dbo].[subskribe_3rb] ([userid], [bossname],[not_15m], [server], [time_kill] )
	values
		((select [id]
			from [dbo].[Users]
			Where [telegram_id] = @tg_id),
			@bossname, @not_time, @server, @timekill);
else
	insert into [dbo].[subskribe_3rb] ([userid], [bossname],[not_5m], [server], [time_kill] )
	values
		((select [id]
			from [dbo].[Users]
			Where [telegram_id] = @tg_id),
	@bossname, @not_time, @server, @timekill);
go

