CREATE PROCEDURE [dbo].[create_fort]
(@name varchar(200),@waittime int, @server varchar(200))
AS
insert into
[dbo].[Fortness] 
([name], [time],[server])
values (@name,@waittime, @server)
go

