CREATE PROCEDURE [dbo].[create_user]
(@username varchar(200), @telegram_id int)
AS
INSERT INTO [dbo].[Users]
([telegram_id],[username])
VALUES
(@telegram_id,@username)
go

