CREATE PROCEDURE [dbo].[select_boss_type]
(@bosstypee int, @server varchar(200))
AS
select [bossname] from [dbo].[bosses]
where [bosstype] = @bosstypee and [Server] = @server
go

