CREATE PROCEDURE [dbo].[update_subscribe]
(@tg_id int,@bossname varchar(200),@subsckribe_tybe varchar(200),@not_time varchar(200), @server varchar(200))
AS

if @subsckribe_tybe = 'not_1h'
	update [dbo].[subskribes]
    SET
    [not_1h] = @not_time
    WHERE userid in (select [id]
					from [dbo].[Users]
					Where [telegram_id] = @tg_id) and
					bosid in (select [id]
						from [dbo].[bosses]
						where [bossname] = @bossname and [Server] = @server)


if @subsckribe_tybe = 'not_30m'
	update [dbo].[subskribes]
    SET
    [not_30m] = @not_time
    WHERE userid in (select [id]
        from [dbo].[Users]
        Where [telegram_id] = @tg_id) and
        bosid in (select [id]
          from [dbo].[bosses]
          where [bossname] = @bossname and [Server] = @server )

if @subsckribe_tybe = 'not_15m'
	update [dbo].[subskribes]
    SET
    [not_15m] = @not_time
    WHERE userid in (select [id]
        from [dbo].[Users]
        Where [telegram_id] = @tg_id) and
        bosid in (select [id]
          from [dbo].[bosses]
          where [bossname] = @bossname and [Server] = @server )

if @subsckribe_tybe = 'not_5m'
	update [dbo].[subskribes]
    SET
    [not_5m] = @not_time
    WHERE userid in (select [id]
        from [dbo].[Users]
        Where [telegram_id] = @tg_id) and
        bosid in (select [id]
          from [dbo].[bosses]
          where [bossname] = @bossname and [Server] = @server )

go

