
CREATE PROCEDURE [dbo].[select_near_boss_by_id]
(@bosid int)
AS
select [bossname],[startresp]
from [dbo].[bosses]
where [id] = @bosid;
go

