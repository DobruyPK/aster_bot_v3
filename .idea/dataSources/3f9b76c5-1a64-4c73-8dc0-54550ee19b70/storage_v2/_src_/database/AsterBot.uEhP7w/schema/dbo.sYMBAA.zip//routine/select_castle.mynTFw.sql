
CREATE PROCEDURE [dbo].[select_castle]
(@castelname varchar(200), @server varchar(200))
AS
select [name], [time]
from [dbo].[Castles]
where [name] = @castelname and [Server] = @server;
go

