CREATE PROCEDURE [dbo].[get_fort_time]
(@name  varchar(200), @server varchar(200))
AS
select [time]
from [dbo].[Fortness]
where [name] = @name and [Server] = @server
go

