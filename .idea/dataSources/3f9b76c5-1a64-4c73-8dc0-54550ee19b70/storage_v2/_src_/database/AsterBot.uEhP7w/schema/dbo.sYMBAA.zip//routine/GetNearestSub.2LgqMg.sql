-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE PROCEDURE [dbo].[GetNearestSub] AS
BEGIN
	IF OBJECT_ID(N'tempdb..#TempDestinationTable') IS NOT NULL
	BEGIN
	DROP TABLE #TempDestinationTable
	END;
	BEGIN
	SELECT MIN(timeless.TheMin) AS mintime
	INTO #TempDestinationTable
	FROM(Select *,
			Case When [not_1h] < [not_30m] And [not_1h] < [not_15m] And [not_1h] < [not_5m] Then [not_1h]
				When [not_30m] < [not_1h] And [not_30m] < [not_15m] And [not_30m] < [not_5m] Then [not_30m]
				When [not_15m] < [not_1h] And [not_15m] < [not_30m] And [not_15m] < [not_5m] Then [not_15m]
				Else [not_5m]
				End As TheMin
		From   subskribes
		Where ([not_1h] IS NOT NULL) or ([not_30m] IS NOT NULL) or ([not_15m] IS NOT NULL) or ([not_5m] IS NOT NULL)) AS timeless
	END;
	BEGIN
	SET NOCOUNT ON
	SELECT *
	FROM subskribes
	WHERE ([not_1h] in (select mintime from #TempDestinationTable)) OR
		  ([not_30m] in (select mintime from #TempDestinationTable)) OR
		  ([not_15m] in (select mintime from #TempDestinationTable)) OR
		  ([not_5m] in (select mintime from #TempDestinationTable))
	END;
END;
go

