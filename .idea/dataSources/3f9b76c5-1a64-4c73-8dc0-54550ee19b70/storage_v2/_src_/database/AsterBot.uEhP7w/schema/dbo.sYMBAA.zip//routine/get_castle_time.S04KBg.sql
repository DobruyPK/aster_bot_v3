CREATE PROCEDURE [dbo].[get_castle_time]
(@name  varchar(200), @server varchar(200))
AS
select [time]
from [dbo].[Castles]
where [name] = @name and [Server] = @server
go

