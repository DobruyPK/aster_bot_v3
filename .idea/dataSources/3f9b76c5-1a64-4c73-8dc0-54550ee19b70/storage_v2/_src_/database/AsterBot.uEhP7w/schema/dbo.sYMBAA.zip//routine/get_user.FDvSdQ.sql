CREATE PROCEDURE [dbo].[get_user]
(@telegram_id int)
AS
select [telegram_id]
from [dbo].[Users]
where [telegram_id] = @telegram_id
go

