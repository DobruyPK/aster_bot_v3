CREATE PROCEDURE [dbo].[get_all_boss]
AS
select *
from [dbo].[bosses]
go

