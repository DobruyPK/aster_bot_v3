CREATE PROCEDURE [dbo].[get_all_fort_name_by_server]
(@server varchar(200))
AS
select [name]
from [dbo].[Fortness]
where [server] = @server and [time] > 4
go

