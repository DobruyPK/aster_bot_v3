CREATE PROCEDURE [dbo].[get_all_user_id]
AS
select [id], [telegram_id]
from [dbo].[Users]
go

