CREATE PROCEDURE [dbo].[all_get_subscribe]
AS
select [id], [telegram_id]
from [dbo].[Users]
go

