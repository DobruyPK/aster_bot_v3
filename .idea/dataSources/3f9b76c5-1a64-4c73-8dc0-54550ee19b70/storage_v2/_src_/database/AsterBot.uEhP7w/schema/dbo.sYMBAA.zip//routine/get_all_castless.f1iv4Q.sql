CREATE PROCEDURE [dbo].[get_all_castless]
AS
select [name], [time]
from [dbo].[Castles]
go

