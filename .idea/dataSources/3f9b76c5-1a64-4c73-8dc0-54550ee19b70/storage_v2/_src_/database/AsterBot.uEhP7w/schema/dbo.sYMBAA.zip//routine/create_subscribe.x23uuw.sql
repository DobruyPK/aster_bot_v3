CREATE PROCEDURE [dbo].[create_subscribe]
(@tg_id int,@bossname varchar(200),@subsckribe_tybe varchar(200),@not_time datetime2, @server varchar(200))
AS
if @subsckribe_tybe = 'not_1h'
	insert into [dbo].[subskribes] ([userid], [bosid],[not_1h], [Server] )
	values
		((select [id]
			from [dbo].[Users]
			Where [telegram_id] = @tg_id),
		  (select [id]
			from [dbo].[bosses]
			Where [bossname] = @bossname and [Server] = @server ),
	  @not_time, @server);
else if @subsckribe_tybe = 'not_30m'
	insert into [dbo].[subskribes] ([userid], [bosid],[not_30m], [Server] )
	values
		((select [id]
			from [dbo].[Users]
			Where [telegram_id] = @tg_id),
		  (select [id]
			from [dbo].[bosses]
			Where [bossname] = @bossname and [Server] = @server),
		  @not_time, @server);
else if @subsckribe_tybe = 'not_15m'
	insert into [dbo].[subskribes] ([userid], [bosid],[not_15m], [Server] )
	values
		((select [id]
			from [dbo].[Users]
			Where [telegram_id] = @tg_id),
		  (select [id]
			from [dbo].[bosses]
			Where [bossname] = @bossname and [Server] = @server),
		  @not_time, @server);
else
	insert into [dbo].[subskribes] ([userid], [bosid],[not_5m], [Server] )
	values
		((select [id]
			from [dbo].[Users]
			Where [telegram_id] = @tg_id),
		  (select [id]
			from [dbo].[bosses]
			Where [bossname] = @bossname and [Server] = @server),
		  @not_time, @server);
go

