CREATE PROCEDURE [dbo].[delete_subsckribe_server_status]
(@tg_id int, @server varchar(200))
AS
DELETE FROM [dbo].[subsckribe_server_status]
WHERE [userid] = (select id
				  from dbo.Users
				  where telegram_id= @tg_id) and [server_name] = @server
go

