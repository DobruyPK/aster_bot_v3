CREATE PROCEDURE [dbo].[create_subsckribe_server_status]
(@tg_id int, @server varchar(200))
AS
insert into
[dbo].[subsckribe_server_status] 
([server_name], [userid])
values (@server, (select [id]
			from [dbo].[Users]
			Where [telegram_id] = @tg_id));
go

