CREATE PROCEDURE [dbo].[deleteNotactivesubsckribe]
AS
DELETE FROM [dbo].[subskribes]
WHERE [not_1h] = '3000-01-01 00:00:00.0000000' and
	  [not_30m] = '3000-01-01 00:00:00.0000000' and
	  [not_15m] = '3000-01-01 00:00:00.0000000' and
	  [not_5m] = '3000-01-01 00:00:00.0000000'
go

