CREATE PROCEDURE [dbo].[get_all_tg_ids]
  @List varchar(max)
AS
SELECT [telegram_id]
FROM [dbo].[Users]
WHERE [id] in(SELECT value FROM STRING_SPLIT(@List, ','))
go

