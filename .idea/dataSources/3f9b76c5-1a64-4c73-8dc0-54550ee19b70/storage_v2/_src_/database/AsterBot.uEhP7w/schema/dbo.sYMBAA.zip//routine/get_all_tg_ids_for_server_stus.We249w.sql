Create PROCEDURE [dbo].[get_all_tg_ids_for_server_stus]
AS
SELECT [telegram_id]
FROM [dbo].[Users]
go

