CREATE PROCEDURE [dbo].[get_all_castle_name_by_server]
(@server varchar(200))
AS
select [name]
from [dbo].[Castles]
where [server] = @server
go

