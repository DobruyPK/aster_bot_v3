CREATE PROCEDURE [dbo].[create_boss]
(@bossname varchar(200),@killdatettime datetime2, @bosstype int, @startresp datetime2, @endresp datetime2, @server varchar(200))
AS
insert into
[dbo].[bosses] 
([killdatettime], [bossname], [bosstype],[startresp],[endresp],[Server])
values (@killdatettime,@bossname, @bosstype, @startresp,  @endresp, @server)
go

