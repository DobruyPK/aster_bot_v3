CREATE PROCEDURE [dbo].[update_castle]
(@name varchar(200),@time datetime2, @server varchar(200))
AS
UPDATE [dbo].[Castles]
SET
[time] = @time
WHERE [name] = @name and [server] = @server;
go

