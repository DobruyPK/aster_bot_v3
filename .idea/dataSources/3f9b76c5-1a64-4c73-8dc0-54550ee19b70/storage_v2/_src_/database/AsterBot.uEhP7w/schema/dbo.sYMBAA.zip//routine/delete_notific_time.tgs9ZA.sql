CREATE PROCEDURE [dbo].[delete_notific_time]
(@sids varchar(max),@subsckribe_tybe varchar(200))
AS

if @subsckribe_tybe = 'not_1h'
	update [dbo].[subskribes]
    SET
    [not_1h] = '3000-01-01 00:00:00.0000000'
    WHERE id in(SELECT value FROM STRING_SPLIT(@sids, ','))


if @subsckribe_tybe = 'not_30m'
	update [dbo].[subskribes]
    SET
    [not_30m] = '3000-01-01 00:00:00.0000000'
    WHERE id in(SELECT value FROM STRING_SPLIT(@sids, ','))

if @subsckribe_tybe = 'not_15m'
	update [dbo].[subskribes]
    SET
    [not_15m] = '3000-01-01 00:00:00.0000000'
    WHERE id in(SELECT value FROM STRING_SPLIT(@sids, ','))

if @subsckribe_tybe = 'not_5m'
	update [dbo].[subskribes]
    SET
    [not_5m] = '3000-01-01 00:00:00.0000000'
    WHERE id in(SELECT value FROM STRING_SPLIT(@sids, ','))

go

