CREATE PROCEDURE last_notific AS
IF OBJECT_ID(N'tempdb..#TempDestinationTable') IS NOT NULL
                        BEGIN
                        DROP TABLE #TempDestinationTable
                        END
go

