CREATE PROCEDURE [dbo].[update_fort]
(@name varchar(200),@time int, @server varchar(200))
AS
UPDATE [dbo].[Fortness]
SET
[time] = @time
WHERE [name] = @name and [server] = @server;
go

