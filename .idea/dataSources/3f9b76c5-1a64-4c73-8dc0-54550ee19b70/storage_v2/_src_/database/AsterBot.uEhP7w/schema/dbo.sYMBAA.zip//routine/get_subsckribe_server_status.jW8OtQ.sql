-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE PROCEDURE [dbo].[get_subsckribe_server_status]
(@tg_id int, @server varchar(200))
AS
select *
from [dbo].[subsckribe_server_status]
where [userid] in (SELECT [id]
                FROM [dbo].[Users]
                WHERE [telegram_id] = @tg_id) and [server_name]= @server
go

