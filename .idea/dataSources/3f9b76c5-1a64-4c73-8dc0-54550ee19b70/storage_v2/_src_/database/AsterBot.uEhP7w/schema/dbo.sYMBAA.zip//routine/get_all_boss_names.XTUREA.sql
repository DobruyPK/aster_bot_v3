CREATE PROCEDURE [dbo].[get_all_boss_names]
(@server varchar(200))
AS
select [bossname]
from [dbo].[bosses]
where [Server] = @server
go

