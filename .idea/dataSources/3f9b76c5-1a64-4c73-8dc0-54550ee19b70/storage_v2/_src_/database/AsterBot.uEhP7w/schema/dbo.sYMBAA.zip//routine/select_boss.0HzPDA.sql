
CREATE PROCEDURE [dbo].[select_boss]
(@bossname varchar(200), @server varchar(200))
AS
select [bossname], [killdatettime],[startresp],[endresp]
from [dbo].[bosses]
where [bossname] = @bossname and [Server] = @server;
go

