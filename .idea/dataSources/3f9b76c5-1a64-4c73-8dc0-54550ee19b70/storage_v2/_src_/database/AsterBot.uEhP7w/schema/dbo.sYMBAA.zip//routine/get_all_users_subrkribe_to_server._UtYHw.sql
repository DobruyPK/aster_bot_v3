-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE PROCEDURE [dbo].[get_all_users_subrkribe_to_server]
(@server varchar(200))
AS
select [telegram_id]
from dbo.Users
where id = (select [userid]
from [dbo].[subsckribe_server_status]
where [server_name]= @server)
go

