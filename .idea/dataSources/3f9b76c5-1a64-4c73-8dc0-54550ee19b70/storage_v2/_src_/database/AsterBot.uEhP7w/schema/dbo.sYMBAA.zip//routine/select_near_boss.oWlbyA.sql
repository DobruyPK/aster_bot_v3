CREATE PROCEDURE [dbo].[select_near_boss]
AS
select min([startresp])
from [dbo].[bosses]
go

